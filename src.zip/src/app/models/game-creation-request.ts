import { Difficulty } from "./difficulty"; // Import the Difficulty enum

export interface GameCreationRequest {
  difficulty?: Difficulty; // Optional: for predefined difficulties (EASY, MEDIUM, HARD)
  rows?: number;          // Optional: for custom games (number of rows)
  cols?: number;          // Optional: for custom games (number of columns)
  mines?: number;         // Optional: for custom games (number of mines)
}
