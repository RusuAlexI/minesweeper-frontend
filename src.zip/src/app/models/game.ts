export interface Cell {
  isMine: boolean;
  isRevealed: boolean;
  isFlagged: boolean;
  adjacentMines: number;
}

export interface GameBoard {
  id: string;
  board: Cell[][];
  rows: number;
  cols: number;
  mines: number;
  status: 'IN_PROGRESS' | 'WON' | 'LOST';
  startTime: number;
  endTime?: number;
}
