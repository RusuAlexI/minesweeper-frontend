// minesweeper-game-angular/src/app/models/game-board.ts
import { Difficulty } from './difficulty'; // Import Difficulty enum

export interface Cell {
  row: number;
  col: number;
  mine: boolean;
  revealed: boolean;
  flagged: boolean;
  adjacentMines: number;
}

export interface GameBoard {
  gameId: string; // Add gameId
  rows: number;
  cols: number;
  mines: number;
  board: Cell[][];
  status: 'NOT_STARTED' | 'IN_PROGRESS' | 'WON' | 'LOST'; // Or use an enum GameStatus
  difficulty: Difficulty; // Add difficulty
  startTime: number; // Add startTime (timestamp)
  timeTaken: number; // Add timeTaken (milliseconds)
}
