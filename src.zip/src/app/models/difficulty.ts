export enum Difficulty {
  EASY = 'EASY',
  MEDIUM = 'MEDIUM',
  HARD = 'HARD',
  CUSTOM = 'CUSTOM' // Add CUSTOM to represent custom game settings
}
