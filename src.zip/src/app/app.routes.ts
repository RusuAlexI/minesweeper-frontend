import { Routes } from '@angular/router';
import {BoardComponent} from './board/board.component';
import {AppComponent} from './app.component';

export const routes: Routes = [
  { path: '', component: AppComponent }
];
