import { Component, Input } from '@angular/core';
import { GameBoard } from '../models/game';

@Component({
  selector: 'app-board',
  templateUrl: './board.component.html',
  styleUrls: ['./board.component.css']
})
export class BoardComponent {
  @Input() game!: GameBoard;

  handleClick(row: number, col: number): void {
    this.game.board[row][col].isRevealed = true;
  }
}
