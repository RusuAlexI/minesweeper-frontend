import { Component } from '@angular/core';
import { GameBoard } from './models/game';

@Component({
  selector: 'app-root',
  template: `<h1>Demo</h1><app-board [game]="game"></app-board>`,
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  game: GameBoard = {
    id: '1',
    rows: 2, cols: 2, mines: 0,
    status: 'IN_PROGRESS',
    startTime: Date.now(),
    board: [
      [{ isMine: false, isRevealed: false, isFlagged: false, adjacentMines: 0 },
        { isMine: false, isRevealed: false, isFlagged: false, adjacentMines: 0 }],
      [{ isMine: false, isRevealed: false, isFlagged: false, adjacentMines: 0 },
        { isMine: false, isRevealed: false, isFlagged: false, adjacentMines: 0 }]
    ]
  };
}
